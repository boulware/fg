#include "Blit.h"

#include <algorithm>

namespace Blit
{
    void
    BlitBitmap(bitmap *SrcBitmap, bitmap *DestBitmap,
               int16 SrcX, int16 SrcY,
               int16 DestX, int16 DestY,
               uint16 Width, uint16 Height,
               bool32 Transparency = false)               
    {
        // If part of the bitmap to be drawn is outside the destination bitmap, these will optimize
        // the call to a BlitBitmap that only blits the part that's inside the destination bitmap.
        if(DestX < 0)
        {
            SrcX = min(Width, -DestX);
            Width = max(Width + DestX, 0);
            DestX = 0;
        }
        if(DestY < 0)
        {
            SrcY = min(Height, -DestY);
            Height = max(Height + DestY, 0);
            DestY = 0;
        }
        if(DestX + Width > DestBitmap->Width)
        {
            Width = max(DestBitmap->Width - DestX, 0);
        }
        if(DestY + Height > DestBitmap->Height)
        {
            Height = max(DestBitmap->Height - DestY, 0);
        }
        
        uint32 *SrcOrigin = ((uint32 *)SrcBitmap->Pixels) + SrcX + SrcY * SrcBitmap->Width;
        uint32 *DestOrigin = ((uint32 *)DestBitmap->Pixels + DestX + DestY * DestBitmap->Width);
        for(uint16 Y = 0;
            Y < Height;
            ++Y)
        {
            for(uint16 X = 0;
                X < Width;
                ++X)
            {
                uint32 CurrentPixel = *(SrcOrigin + X + SrcBitmap->Width * Y);
                // {255, 0, 255} is the transparency color.
                if(Transparency)
                {
                    if((CurrentPixel & (0x00FFFFFF)) != 0x00FF00FF)
                    {
                        *(DestOrigin + X + DestBitmap->Width * Y) = *(SrcOrigin + X + SrcBitmap->Width * Y);
                    }
                }
                else
                {
                    *(DestOrigin + X + DestBitmap->Width * Y) = *(SrcOrigin + X + SrcBitmap->Width * Y);                    
                }
            }
        }
    }
    
    void
    BlitRectangleToBitmap(bitmap *DestBitmap,
                          uint16 XOffset, uint16 YOffset,
                          uint16 Width, uint16 Height,
                          rgb_color Color,
                          bool32 Transparency = false)
    {
        bitmap Rectangle(Width, Height);
        Rectangle.Clear(Color);

        BlitBitmap(&Rectangle, DestBitmap,
                   0, 0,
                   XOffset, YOffset,
                   Width, Height,
                   Transparency);
    }
// TODO(tyler): Instead of returning a new bitmap in memory, develop a method for pointing to subsets
// of a bitmap and still being able to draw correctly from the memory.
/*
    bitmap*
    GetSubBitmap(bitmap *SrcBitmap,
                 uint16 XOffset, uint16 YOffset,
                 uint16 Width, uint16 Height)
    {
        bitmap *NewBitmap = new bitmap(Width, Height);
    
        BlitBitmap(SrcBitmap, NewBitmap,
                   XOffset, YOffset,
                   0, 0,
                   Width, Height);
    
        return NewBitmap;
    }
*/
    void
    BlitBufferToWindow(bitmap *Buffer, HWND Window)
    {
        HDC DeviceContext = GetDC(Window);
        
        RECT ClientRect;
        GetClientRect(Window, &ClientRect);
        
        StretchDIBits(DeviceContext,
                      0, 0,
                      ClientRect.right - ClientRect.left, ClientRect.bottom - ClientRect.top,
                      0, 0,
                      Buffer->Width, Buffer->Height,
                      Buffer->Pixels,
                      &Buffer->Info,
                      DIB_RGB_COLORS, SRCCOPY);

        ReleaseDC(Window, DeviceContext);
    }
}
