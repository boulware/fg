#if !defined(BLIT_H)

#include "bitmap.h"
#include "Color.h"

namespace Blit
{
}

#define BLIT_H
#endif
